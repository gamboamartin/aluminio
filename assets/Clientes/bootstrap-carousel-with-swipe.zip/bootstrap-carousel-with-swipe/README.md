# Bootstrap carousel with swipe

A Pen created on CodePen.io. Original URL: [https://codepen.io/Winmuthu/pen/aBQqOQ](https://codepen.io/Winmuthu/pen/aBQqOQ).

Bootstrap default carousel with swipe and touch gestures. How to add the swipes gesture to comand the Bootstrap carousel on mobile devices.